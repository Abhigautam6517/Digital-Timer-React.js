import {Timer} from './components/Timer.js';
import './App.css';

function App() {
  return (
    <div>
      <Timer/>
    </div>
  );
}

export default App;
